#ifndef __KERN_TRAP_TRAP_H__
#define __KERN_TRAP_TRAP_H__

struct trapframe;

#endif /* !__KERN_TRAP_TRAP_H__ */

