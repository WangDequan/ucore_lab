#ifndef __KERN_SCHEDULE_SCHED_STRIDE_H__
#define __KERN_SCHEDULE_SCHED_STRIDE_H__

#include <sched.h>

extern struct sched_class stride_sched_class;

#endif /* !__KERN_SCHEDULE_SCHED_STRIDE_H__ */

